swig2.0 -python wiringpi.i
sudo python setup.py build install
sudo python test.py
