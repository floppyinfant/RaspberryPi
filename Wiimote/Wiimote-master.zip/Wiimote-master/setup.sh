sudo apt-get update
sudo apt-get install --no-install-recommends bluetooth -y
sudo apt-get install python-cwiid
