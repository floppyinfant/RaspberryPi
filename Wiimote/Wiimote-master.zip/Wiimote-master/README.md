Wiimote
=======

All the necessary code and commands for using a Wiimote with the Raspberry Pi (Python)

This GitHub repository accompanies my YouTube tutorial for using the Nintendo Wiimote with the Raspberry Pi! You can find it here: https://www.youtube.com/watch?v=bO5-FjLe5xE&list=UUfY8sl5Q6VKndz0nLaGygPw

I'll leave it to the tutorial to do the explaining! 

Enjoy!

Matt

The Raspberry Pi Guy

www.youtube.com/theraspberrypiguy

www.theraspberrypiguy.com

theraspberrypiguy@gmail.com

@RaspberryPiGuy1
